package Labs.PostfixCalculator;

// from Goodrich and Tamassia Data Structures and Algorithms in Java
// copyright of authors.

public class StackFullException extends RuntimeException {

    public StackFullException(String err) {
        super(err);
    }

}
